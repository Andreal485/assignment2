package com.meritamerica.assignment2;

public class CheckingAccount {
	//attributes needed in our class
    private double Balance = 0;
    private double InterestRate = .0001;
    private double futureValue;
    private long accountNumber = (long) Math.random()*(10000000);
    
	

    //returns the account number which is randomly generated
    public long getAccountNumber() {
		return accountNumber;
	}
    //constructor for the checking account which requires an opening balance
    public CheckingAccount(double openingBalance) {
        Balance = openingBalance;
}
    //method which allows an amount to be subtracted or withdrawn from the account with the condition that the amount be less than or equal to the current balance 
    public boolean withdraw(double amount) {
        if (amount > Balance) {
            System.out.println("Unable to process transaction.");
            return false;

        } else {
            Balance -= amount;
            System.out.println("The transaction was a success! Your new balance is:" + Balance);
            return true;
        }
}	
    //allows an amount to be added or deposited to the account with the condition that the amount is not negative or 0
    public boolean deposit(double amount){
        if (amount <= 0) {
            System.out.println("Unable to process transaction.");
            return false;

        } else {
            Balance += amount;
            System.out.println("The transaction was a success! Your new balance is:" + Balance);
            return true;

        }
    }
    //getters for this classes fields
    public double getInterestRate() {
        return InterestRate;
    }

    public double getBalance() {
        return Balance;
    }
    //returns the future value based on the years passed as a parameter and te balance and interest rate
    public double futureValue(int years){
        futureValue = Balance * (Math.pow( (1+ InterestRate), years));
        return futureValue;

    }
    //overrides the toString method so that it returns the future value , balance, and interest rate
    @Override
    public String toString(){
        return "Checking Account Balance: $" + Math.round(100* getBalance())/100.0 + "\nChecking Account " +
                "interest rate: " + (10* getInterestRate()) + "%\nChecking Account Balance in 3 years: $" +
                Math.round(100*futureValue(3))/100.0+ ".";
    }

}
