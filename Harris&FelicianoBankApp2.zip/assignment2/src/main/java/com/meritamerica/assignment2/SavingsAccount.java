package com.meritamerica.assignment2;

public class SavingsAccount {
	//attributes for this class: double for the balance in USD, the interest rate as a double as well
	//and a randomly generated account number
    private double Balance = 0;
    private double savingAccountInterestRate = .01;
    private long accountNumber = (long) Math.random()*20000000;
    
    	

    //getter for our account number allowing it to stay private
    public long getAccountNumber() {
		return accountNumber;
	}


    //an opening balance is needed to instantiate this object
	public SavingsAccount(double startBalance) {
        Balance = startBalance;

    }
	//methods withdraws funds from the account with condition that the withdrawal does not exceed the account balance
    public boolean withdraw(double amount) {
        if (amount > Balance) {
            System.out.println("Unable to process transaction.");
            return false;

        } else {
            Balance -= amount;
            System.out.println("The transaction was a success! Your new balance is:" + Balance);
            return true;
        }
    }
    	//methods deposits money into account with condition that the amount is not 0 or negative
        public boolean deposit ( double amount){
            if (amount <= 0) {
                System.out.println("Unable to process transaction.");
                return false;

            } else {
                Balance += amount;
                System.out.println("The transaction was a success! Your new balance is:" + Balance);
                return true;

            }
        }
        //getters for other fields in this method
        public double getInterestRate() {
            return savingAccountInterestRate;
        }

        public double getBalance() {
            return Balance;
        }
        //returns future value by taking in an amount of years and calculating the value of the account with interest after the amount of years has passed
        
        public double futureValue ( int years){
            return Balance * (Math.pow((1 + savingAccountInterestRate), years));

        }
        //Overrides the toString method to return the savings account balance interest rate and future value
        @Override
        public String toString(){
            return "Savings Account Balance: " + Math.round(100* Balance)/100.0 + ".\nSavings Account Interest Rate: " +
                    (getInterestRate()*10) + "%.\nSavings Account Balance in 3 years: " + Math.round(100*futureValue(3))/100;
        }
    }



