package com.meritamerica.assignment2;

import java.util.Arrays;

public class AccountHolder {

	private String firstName;
	private String middleName;
	private String lastName;
	private String ssn;
	
	private CheckingAccount[] checkingAccounts;
	private int checkingAccountIndex;
	private SavingsAccount[] savingsAccounts;
	private int savingsAccountIndex;
	private CDAccount[] cdAccounts;
	private int cdAccountIndex;
	
	public AccountHolder() {}

	public AccountHolder(String firstName, String middleName, String lastName, String ssn) {
		// setting the attributes to the value from the constructor parameters
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.ssn = ssn;		
		this.checkingAccountIndex = 0;
		this.checkingAccounts = new CheckingAccount[1];
		this.savingsAccountIndex = 0;
		this.savingsAccounts = new SavingsAccount[1];
		this.cdAccountIndex = 0;
		this.cdAccounts = new CDAccount[1];
	}
	//method for instantiating a checking account object and then passing this object into the overloaded version of this method
	public void addCheckingAccount(double openingBalance) {
		CheckingAccount newAccount = new CheckingAccount(openingBalance);
		addCheckingAccount(newAccount);
	}

	//method creates a new array that is a copy of the current array plus the checking account that is being instantiated
	//and passed in as a parameter in this version of the overloaded method if the balance of this checking account
	// plus the sum of the other checking and savings accounts is over 250,000 the account will not be created
	//if it is under 250,000 the number of checking accounts in the array will be assessed and a new array
	//will be created with a size of the current arrays +1 this array is named temp we then have a for loop
	//and copy the index of our old array into our new array
	// finally we copy the new checking account object into the last position which is the new array limit
	//and we increase the index and set our checking account array to the new array we just created
	public void addCheckingAccount(CheckingAccount checkingAccount) {
		if(getCheckingBalance() + getSavingsBalance() + checkingAccount.getBalance() >= 250000) {
			System.out.println("Unable to create a new account, balance is too high.");
			return;
		}
		
		int currentArrayLimit = this.checkingAccountIndex;
		CheckingAccount[] temp = new CheckingAccount[currentArrayLimit + 1];
		
		for(int i=0; i<currentArrayLimit; i++) {
			temp[i] = this.checkingAccounts[i];
		}
		
		temp[currentArrayLimit] = checkingAccount;
		this.checkingAccountIndex ++;
		this.checkingAccounts = temp;
	}
	//similar to checking account methods except replaces with savings account objects
	public void addSavingsAccount(double openingBalance) {
		SavingsAccount newAccount = new SavingsAccount(openingBalance);
		addSavingsAccount(newAccount);
	}
	
	public void addSavingsAccount(SavingsAccount savingsAccount) {
		if(getCheckingBalance() + getSavingsBalance() + savingsAccount.getBalance() >= 250000 ) {
			System.out.println("Unable to create account. Balance too high.");
			return;
			
		}
		 int currentArrayLimit = this.savingsAccountIndex;
		 SavingsAccount[] temp = new SavingsAccount[currentArrayLimit + 1];
		 
		 for(int i = 0; i < currentArrayLimit; i++) {
			 temp[i] = this.savingsAccounts[i];
		 }
		 
		 temp[currentArrayLimit] = savingsAccount;
		 this.savingsAccountIndex++;
		 this.savingsAccounts = temp;
	}
	//method to add CDAccounts to an array
	//this method is similar to to the addChecking and savings except we need a CD offering for the CDAccounts constructors parameters to be filled
	public void addCDAccount(CDOffering offering, double openingBalance) {
		CDAccount newAccount = new CDAccount(offering, openingBalance);
		addCDAccount(newAccount);
		
	}
		//if we did not instantiate the cdAccount  properly we will not be able to add it to the array
		//the rest of this method is similar to add checking and savings but there is not a condition which requires the balance to be under a certain amount 
		public void addCDAccount(CDAccount cdAccount) {
			if(cdAccount == null) {
				System.out.println("Unable to find account.");
			}
		
		int currentArrayLimit = this.cdAccountIndex;
		CDAccount [] temp = new CDAccount[currentArrayLimit + 1];
		
		for (int i = 0; i < currentArrayLimit; i++) {
			temp[i] = this.cdAccounts[i];
		}
		
		temp[currentArrayLimit] = cdAccount;
		this.cdAccountIndex++;
		this.cdAccounts = temp;
	}


	
	// create getters and setters for retrieving and updating the value of the
	// variables
	public String getFirstName() {
		return firstName;
	}

	public void setFirstname(String name) {
		this.firstName = name;

	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String midName) {
		this.middleName = midName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lstName) {
		this.lastName = lstName;
	}

	public String getSSN() {
		return ssn;
	}

	public void setSSN(String SSN) {
		this.ssn = SSN;

	}

	public CheckingAccount[] getCheckingAccounts() {
		return this.checkingAccounts;
	}
	
	public SavingsAccount[] getSavingsAccounts() {
		return this.savingsAccounts;
	}
	
	public CDAccount[] getCDAccounts() {
		return this.cdAccounts;
	}

	public int getNumberOfCheckingAccounts() {
		return this.checkingAccountIndex;
	}
	
	public int getNumberOfSavingsAccounts() {
		return this.savingsAccountIndex;

	}
	
	public int getNumberOfCDAccounts() {
		return this.cdAccountIndex;

	}
	//this method iterates over the arrays to check the balances of the accounts and adds them to a variable sum 
	//the sum is returned to get the total balance of the accounts of a type
	public double getCheckingBalance() { 
		double sum = 0;
		
		for (int i = 0; i < this.checkingAccountIndex; i++) {
			sum += this.checkingAccounts[i].getBalance();
		}
		return sum;
	}
	
	public double getSavingsBalance() {
		double sum = 0;
		
		for (int i = 0; i  < this.savingsAccountIndex; i++) {
			sum += this.savingsAccounts[i].getBalance();
		}
		
		return sum;
				
	}
	
	public double getCDAccountsBalance() {
		if(this.cdAccounts[0] == null) {
			return 0;
		}
		double sum = 0;
		
		for (int i = 0; i < this.cdAccounts.length; i++) {
			sum += this.cdAccounts[i].getBalance();
		}
		
		return sum;
		
	}
	
	public double getCDBalance() {
	return getCDAccountsBalance();
}
	
	
	//this method returns the combined balances of the accounts held in all 3 array types by calling the corresponding getBalance methods
	public double getCombinedBalance() {
		double accountSums = getCheckingBalance();
		accountSums += getCDAccountsBalance();
		accountSums += getSavingsBalance();
		return accountSums;
	}
	//overrides the toString method to return the attributes of the class as well as the first checking and savings account added
	@Override
	public String toString() {
		return ("Name: " + this.firstName + " " + this.middleName + " " + this.lastName + "\nSSN: " + this.ssn + "\n"
				+ checkingAccounts[0].toString() + "\n" + savingsAccounts[0].toString());

	}
}


