package com.meritamerica.assignment2;

import java.util.Arrays;
import java.util.Random;

public class MeritBank {
	private static AccountHolder[] accountHolders = new AccountHolder[100];
	private static int accountHolderIndex = 0;
	private static CDOffering[] cdOfferings = new CDOffering[100];
	private static long nextAccountNumber = 1234567;
	
	//method to add account holders to our account holder array
	//increases the index counter so we can keep track of how many elements are in our array and easily add 1 to it to create another
	public static void addAccountHolder(AccountHolder accountHolder) {
		accountHolders[accountHolderIndex] = accountHolder;
		accountHolderIndex++;
		
	}
	
	public static AccountHolder[] getAccountHolders() { //returns the array of accountHolders
		return  accountHolders;	
	}
	//returns the array of cd offerings
	public static CDOffering[] getCDOfferings() {
		return cdOfferings;
	}
	//this method iterates over the available cd offerings in the array and compares them by interest rate 
	//it returns the offering with the highest interest rate regardless of term
	public static CDOffering getBestCDOffering(double depositAmount) {
		if(cdOfferings == null) {
			return null;
		}
		
		double bestValue = 0;
		int bestIndex = -1;
		
		for (int i = 0; i < cdOfferings.length; i++) {
			if(cdOfferings[i].getInterestRate() > bestValue) {
				bestValue = cdOfferings[i].getInterestRate();
				bestIndex = i;
			}
		}
		
		return cdOfferings[bestIndex];		
	}
	//this method returns the second best offering by making sure that the value is the greatest in the array but also not equal to the best offering
	//so it must return the second best offering
	public static CDOffering getSecondBestCDOffering(double depositAmount) {
		if(cdOfferings == null) {
			return null;
		}
		CDOffering best = getBestCDOffering(depositAmount);
		
		double secondBestValue = 0;
		int secondBestIndex = -1;		
		
		for (int i = 0; i < cdOfferings.length; i ++) {
			if(cdOfferings[i].getInterestRate() > secondBestValue && !best.equals(cdOfferings[i])) {
				secondBestValue = cdOfferings[i].getInterestRate();
				secondBestIndex = i;
			}
		}
		
		return cdOfferings[secondBestIndex];
		
	} 
	
	public static void clearCDOfferings() {
		cdOfferings = null;     //to clear the existing cd offerings
		
	} 
	//this method allows new cd offerings to be set
	public static void setCDOfferings(CDOffering[] offerings) {
		int cdOfferingArraySize = offerings.length;
		cdOfferings = new CDOffering[cdOfferingArraySize];
		for (int i = 0; i < cdOfferingArraySize; i++) {
			cdOfferings[i] = offerings[i];
		}
	}
	
	public static long getNextAccountNumber() {
		nextAccountNumber++;
		return nextAccountNumber;
		
	}
	//this method returns the sums of all accounts held by all account holders
	public static double totalBalances() {
		double sum = 0;
		
		for(AccountHolder acctHolder : accountHolders) {
			if(acctHolder == null) {
				break;
			}
			
			
			for(CheckingAccount chkAccountBalance : acctHolder.getCheckingAccounts()) {
				sum += chkAccountBalance.getBalance();
			}
			
			for(SavingsAccount savAccountBalance : acctHolder.getSavingsAccounts()) {
				sum += savAccountBalance.getBalance();
			}
			
			for(CDAccount account : acctHolder.getCDAccounts()) { 
				try {
				sum += account.getBalance();
				} catch (NullPointerException e) {
					System.out.println("Handled null pointer.");
				}
			}
			
		}
	
		return sum;
}
	
	public static double futureValue(double presentValue, double interestRate, int term) {
		double futureValue = presentValue * (Math.pow(1 + presentValue, term));
		return futureValue;
		
	}
}
