package com.meritamerica.assignment2;

import java.util.Date;

public class CDAccount {
	//attributes of this class which include a CD offering
	//the term and interest rate are determined by the cd offering so it is necessary to this class
	private long accountNumber = (long) Math.random()*300000000;
	private double futureValue;
	private double balance;
	private double interestRate;
	private int term;
	CDOffering offering;
	
	//you can choose to pass an offering that has been previously created and a balance to create this object
	public CDAccount(CDOffering offering, double openingBalance) {
		this.offering = offering;
		balance = openingBalance;
	}
	//you can choose to instantiate this object as well as an offering at the same time
	public CDAccount(int term, double interestRate, double openingBalance) {
		this.offering = new CDOffering(term, interestRate);
		balance = openingBalance;
	}

	//returns the future balance of the account based on the interest rate and term provided by the offering
	public double futureValue(){
        futureValue = balance * (Math.pow( (1+ interestRate), term));
        return futureValue;

    }

	//getters that return the attributes of this class
	public long getAccountNumber() {
		return accountNumber;
	}


	public double getBalance() {
		return balance;
	}


	public double getInterestRate() {
		return offering.getInterestRate();
	}


	public int getTerm() {
		return offering.getTerm();
	}

	public Date getStartDate() {
		Date startDate = new Date();
		return startDate;
	}





}
